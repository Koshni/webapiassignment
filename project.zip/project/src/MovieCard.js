//snippet rce
import React, { Component } from 'react';
import {
  Card,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  CardSubtitle,
  Button,
  Modal,
  ModalHeader,
  ModalBody
} from 'reactstrap';

export class MovieCard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      modal: false
    };

    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({
      modal: !this.state.modal
    });
  }

  render() {
    let { title, year, genre, actors, plot, poster } = this.props.movie;
    return (
      <div>
        <Card>
          <CardImg top width="100%" src={poster} alt="Movie poster" />
          <CardBody>
            <CardTitle>{title}</CardTitle>
            <CardSubtitle>{year}</CardSubtitle>
            <br />
            <Button color="dark" onClick={this.toggle}>
              {this.props.buttonLabel}
              View
            </Button>{' '}
            <Button color="dark" onClick={() => this.props.removeMovie(title)}>
              Delete
            </Button>
          </CardBody>
        </Card>
        <Modal
          isOpen={this.state.modal}
          toggle={this.toggle}
          className={this.props.className}
        >
          <ModalHeader toggle={this.toggle}>Movie Details</ModalHeader>
          <ModalBody>
            <CardImg top width="50%" src={poster} alt="Movie poster" />
            <CardTitle>{title}</CardTitle>
            <CardSubtitle>{year}</CardSubtitle>
            <br />
            <CardSubtitle>Genre: {genre}</CardSubtitle>
            <br />
            <CardSubtitle>Actors: {actors}</CardSubtitle>
            <br />
            <CardText>{plot}</CardText>
          </ModalBody>
        </Modal>
      </div>
    );
  }
}

export default MovieCard;
